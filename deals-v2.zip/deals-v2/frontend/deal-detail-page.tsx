'use client';
import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MapPin, DollarSign, Users, Zap, AlertCircle, Building2,
  TrendingUp, Target, Send, Clock, FileText, ExternalLink,
  Phone, Mail, RefreshCw, Sparkles, Flame, Shield, BarChart3,
  Copy, CheckCircle, ChevronDown, ChevronUp, Camera, FolderOpen,
  Globe, Eye, Lock, Share2, Facebook, MessageSquare, Edit3, X
} from 'lucide-react';
import { api } from '@/lib/api';
import { formatCurrency } from '@/lib/format';
import toast from 'react-hot-toast';

type Tab = 'property' | 'dealmath' | 'buyers' | 'dispo';

const STATUS_COLORS: Record<string, string> = {
  DRAFT: 'bg-gray-700/80 text-gray-300',
  NEEDS_INFO: 'bg-amber-900/60 text-amber-300 border border-amber-700/40',
  READY_TO_MATCH: 'bg-blue-900/60 text-blue-300 border border-blue-700/40',
  MATCHED: 'bg-purple-900/60 text-purple-300 border border-purple-700/40',
  READY_TO_BLAST: 'bg-green-900/60 text-green-300 border border-green-700/40',
  CAMPAIGN_ACTIVE: 'bg-emerald-900/60 text-emerald-400 border border-emerald-700/40',
  OFFER_RECEIVED: 'bg-orange-900/60 text-orange-300 border border-orange-700/40',
  ASSIGNED: 'bg-teal-900/60 text-teal-300 border border-teal-700/40',
  CLOSED: 'bg-green-800/60 text-green-200',
  DEAD: 'bg-red-900/60 text-red-400',
  ACTIVE: 'bg-blue-900/60 text-blue-300',
};

function getPriorityBadge(score: number) {
  if (score >= 90) return { label: '🔥 Hot', bg: 'bg-red-900/70 text-red-300 border border-red-700' };
  if (score >= 75) return { label: 'Strong', bg: 'bg-orange-900/70 text-orange-300 border border-orange-700' };
  if (score >= 60) return { label: 'Workable', bg: 'bg-yellow-900/70 text-yellow-300 border border-yellow-700' };
  if (score >= 40) return { label: 'Needs Info', bg: 'bg-blue-900/70 text-blue-300 border border-blue-700' };
  return { label: 'Weak', bg: 'bg-gray-800 text-gray-500 border border-gray-700' };
}

function InfoRow({ label, value, mono = false, href }: { label: string; value: any; mono?: boolean; href?: string }) {
  if (!value && value !== 0) return null;
  return (
    <div className="flex justify-between items-start py-2 border-b border-gray-800/50 last:border-0">
      <span className="text-gray-500 text-sm shrink-0 mr-4">{label}</span>
      {href ? (
        <a href={href} target="_blank" rel="noopener noreferrer"
          className="text-blue-400 text-sm hover:underline flex items-center gap-1">
          {value} <ExternalLink size={11} />
        </a>
      ) : (
        <span className={`text-white text-sm text-right ${mono ? 'font-mono' : ''}`}>{value}</span>
      )}
    </div>
  );
}

function Card({ title, icon: Icon, children, className = '', warning }: any) {
  return (
    <div className={`bg-gray-900 rounded-xl border border-gray-800 overflow-hidden ${className}`}>
      <div className="px-4 py-3 border-b border-gray-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon size={14} className="text-gray-400" />
          <h3 className="text-white text-sm font-medium">{title}</h3>
        </div>
        {warning && <span className="text-amber-400 text-xs flex items-center gap-1"><AlertCircle size={11} />{warning}</span>}
      </div>
      <div className="p-4">{children}</div>
    </div>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
      className="flex items-center gap-1 px-2 py-1 bg-gray-800 hover:bg-gray-700 text-gray-400 text-xs rounded transition">
      {copied ? <CheckCircle size={11} className="text-green-400" /> : <Copy size={11} />}
      {copied ? 'Copied' : 'Copy'}
    </button>
  );
}

function GeneratedOutput({ content, onClose }: { content: string; onClose: () => void }) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(content);
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
      className="mt-3 bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
      <div className="flex items-center justify-between px-3 py-2 border-b border-gray-700">
        <span className="text-gray-400 text-xs font-medium">Generated Output</span>
        <div className="flex items-center gap-2">
          <CopyButton text={text} />
          <button onClick={() => setEditing(!editing)}
            className="flex items-center gap-1 px-2 py-1 bg-gray-700 hover:bg-gray-600 text-gray-400 text-xs rounded transition">
            <Edit3 size={11} /> {editing ? 'Done' : 'Edit'}
          </button>
          <button onClick={onClose} className="p-1 hover:bg-gray-700 rounded text-gray-500 transition">
            <X size={13} />
          </button>
        </div>
      </div>
      {editing ? (
        <textarea value={text} onChange={e => setText(e.target.value)} rows={6}
          className="w-full bg-transparent text-gray-300 text-sm p-3 focus:outline-none resize-none" />
      ) : (
        <p className="text-gray-300 text-sm p-3 leading-relaxed whitespace-pre-wrap">{text}</p>
      )}
    </motion.div>
  );
}

export default function DealDetailPage({ params }: { params: { id: string } }) {
  const { id } = params;
  const qc = useQueryClient();
  const [tab, setTab] = useState<Tab>('property');
  const [showOriginalPost, setShowOriginalPost] = useState(false);
  const [generatedOutput, setGeneratedOutput] = useState<Record<string, string>>({});

  const { data: deal, isLoading } = useQuery({
    queryKey: ['deal', id],
    queryFn: () => api.get(`/deals/${id}`).then(r => r.data),
  });

  const calcAction = useMutation({
    mutationFn: () => api.post(`/deals/${id}/calculate-metrics`).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['deal', id] }); toast.success('Metrics updated!'); },
  });

  const followUpAction = useMutation({
    mutationFn: () => api.post(`/deals/${id}/generate-follow-up`).then(r => r.data),
    onSuccess: (data) => {
      setGeneratedOutput(prev => ({ ...prev, followUp: data.message }));
      toast.success('Follow-up generated!');
    },
  });

  const matchAction = useMutation({
    mutationFn: () => api.post(`/deals/${id}/match-buyers`).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['deal', id] }); toast.success('Buyer match complete!'); },
  });

  const generateContent = useMutation({
    mutationFn: (type: string) => api.post(`/deals/${id}/generate-content`, { type }).then(r => r.data).catch(() => ({
      content: type === 'sms'
        ? `🏠 ${deal?.address}, ${deal?.city} ${deal?.state}\n${deal?.beds}bd/${deal?.baths}ba · ${deal?.sqft?.toLocaleString()} sqft · ${deal?.overallCondition?.replace(/_/g, ' ')}\nAsking: ${deal?.askingPrice ? formatCurrency(deal.askingPrice) : 'TBD'} · ARV: ${deal?.arv ? formatCurrency(deal.arv) : 'TBD'}\n${deal?.description || ''}\nReply for more info or to schedule showing.`
        : type === 'email'
        ? `Subject: New Deal Alert — ${deal?.address}, ${deal?.city} ${deal?.state}\n\nHey [Buyer Name],\n\nWe have a new deal that matches your buy box:\n\n📍 ${deal?.address}, ${deal?.city}, ${deal?.state} ${deal?.zipCode}\n🏠 ${deal?.propertyType} · ${deal?.beds}bd/${deal?.baths}ba · ${deal?.sqft?.toLocaleString()} sqft\n💰 Asking: ${deal?.askingPrice ? formatCurrency(deal.askingPrice) : 'TBD'} · ARV: ${deal?.arv ? formatCurrency(deal.arv) : 'TBD'}\n🔨 Repairs: ${deal?.repairEstimate ? formatCurrency(deal.repairEstimate) : 'TBD'}\n\n${deal?.description || ''}\n\nLet me know if you want more details or want to schedule a showing!\n\nThanks,\nShane`
        : `🏠 New deal available — ${deal?.address}, ${deal?.city} ${deal?.state}\n\n${deal?.beds}bd/${deal?.baths}ba ${deal?.propertyType} · Asking ${deal?.askingPrice ? formatCurrency(deal.askingPrice) : 'TBD'} · ARV ${deal?.arv ? formatCurrency(deal.arv) : 'TBD'}\n\n${deal?.description || ''}\n\nComment or DM for details. #wholesaledeals #realestateinvesting`
    })),
    onSuccess: (data, type) => {
      setGeneratedOutput(prev => ({ ...prev, [type as string]: data.content || data.message }));
    },
  });

  const updateStatus = useMutation({
    mutationFn: (status: string) => api.patch(`/deals/${id}`, { status }).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['deal', id] }); toast.success('Status updated'); },
  });

  if (isLoading) return <div className="p-6 text-gray-500 text-sm">Loading deal...</div>;
  if (!deal) return <div className="p-6 text-red-400 text-sm">Deal not found. <a href="/dashboard/deals" className="underline">Go back</a></div>;

  const spread = deal.spread ?? ((deal.arv || 0) - (deal.askingPrice || 0) - (deal.repairEstimate || 0));
  const priority = getPriorityBadge(deal.dealPriorityScore || 0);
  const missing = deal.missingInfo || [];
  const hasPhotos = !!(deal.photosUrl || deal.googleDriveUrl || (deal.photos && deal.photos.length > 0));
  const hasSource = !!(deal.sourceName || deal.sourcePhone);
  const isJvOrFacebook = ['JV', 'FACEBOOK', 'BIRD_DOG'].includes(deal.sourceType);

  // Generate Google Maps URL from address if not set
  const mapsUrl = deal.googleMapsUrl || (deal.address ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${deal.address}, ${deal.city}, ${deal.state} ${deal.zipCode}`)}` : null);
  const streetViewUrl = deal.streetViewUrl || (deal.address ? `https://www.google.com/maps/@?api=1&map_action=pano&parameters&query=${encodeURIComponent(`${deal.address}, ${deal.city}, ${deal.state}`)}` : null);

  // Public estimates
  const pubEstimates = [deal.zillowEstimate, deal.realtorEstimate, deal.redfinEstimate].filter(Boolean) as number[];
  const avgPublicEstimate = pubEstimates.length > 0 ? pubEstimates.reduce((a, b) => a + b, 0) / pubEstimates.length : 0;
  const seventyPctAvg = avgPublicEstimate * 0.70;
  const seventyPctMinusRepairs = seventyPctAvg - (deal.repairEstimate || 0);

  // Smart main action button
  const getMainAction = () => {
    const coreFieldsMissing = !deal.arv || !deal.askingPrice || !deal.propertyType;
    if (!deal.address || coreFieldsMissing) return { label: 'Complete Missing Info', icon: AlertCircle, color: 'bg-amber-600 hover:bg-amber-500', fn: () => setTab('dispo') };
    if (missing.length > 4) return { label: 'Generate Follow-Up', icon: Send, color: 'bg-blue-600 hover:bg-blue-500', fn: () => followUpAction.mutate() };
    if ((deal.matchedBuyerCount || 0) === 0) return { label: 'Run Buyer Match', icon: Target, color: 'bg-purple-600 hover:bg-purple-500', fn: () => matchAction.mutate() };
    if (!hasPhotos || !deal.accessInfo) return { label: 'Complete Blast Requirements', icon: Camera, color: 'bg-orange-600 hover:bg-orange-500', fn: () => setTab('dispo') };
    if (deal.status === 'READY_TO_BLAST' || (deal.matchedBuyerCount || 0) > 0) return { label: 'Generate Buyer Blast', icon: Zap, color: 'bg-green-600 hover:bg-green-500', fn: () => { setTab('dispo'); generateContent.mutate('sms'); } };
    if (deal.status === 'CAMPAIGN_ACTIVE') return { label: 'Start Campaign', icon: Flame, color: 'bg-red-600 hover:bg-red-500', fn: () => toast.success('Campaign management coming soon!') };
    return { label: 'Run Buyer Match', icon: Target, color: 'bg-blue-600 hover:bg-blue-500', fn: () => matchAction.mutate() };
  };
  const mainAction = getMainAction();
  const isActionLoading = followUpAction.isPending || matchAction.isPending || generateContent.isPending;

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-5">

      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap mb-1.5">
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[deal.status] || 'bg-gray-800 text-gray-400'}`}>
                {(deal.status || 'DRAFT').replace(/_/g, ' ')}
              </span>
              {deal.sourceType && deal.sourceType !== 'MANUAL' && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-gray-800 text-gray-400 border border-gray-700">{deal.sourceType}</span>
              )}
              {deal.propertyType && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-gray-800 text-gray-400 border border-gray-700">{deal.propertyType.replace(/_/g, ' ')}</span>
              )}
              {deal.occupancy && deal.occupancy !== 'UNKNOWN' && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-gray-800 text-gray-400 border border-gray-700">{deal.occupancy.replace(/_/g, ' ')}</span>
              )}
              {deal.dealType && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-900/60 text-indigo-300 border border-indigo-700/40">{deal.dealType}</span>
              )}
            </div>
            <h1 className="text-2xl font-bold text-white leading-tight">{deal.address || 'No Address'}</h1>
            <p className="text-gray-400 text-sm mt-1 flex items-center gap-1">
              <MapPin size={12} />
              {[deal.city, deal.state, deal.zipCode, deal.county].filter(Boolean).join(' · ')}
              {mapsUrl && (
                <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
                  className="ml-2 text-blue-500 hover:text-blue-400 text-xs flex items-center gap-0.5">
                  <ExternalLink size={10} /> Map
                </a>
              )}
            </p>
          </div>
          <button onClick={mainAction.fn} disabled={isActionLoading}
            className={`flex items-center gap-2 px-5 py-2.5 ${mainAction.color} disabled:opacity-50 text-white text-sm rounded-xl font-medium transition shrink-0`}>
            <mainAction.icon size={15} />
            {isActionLoading ? 'Working...' : mainAction.label}
          </button>
        </div>

        {/* Metric Cards */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
          {[
            { label: 'Asking', value: deal.askingPrice ? formatCurrency(deal.askingPrice) : '—', color: 'text-white' },
            { label: 'ARV', value: deal.arv ? formatCurrency(deal.arv) : '—', color: 'text-white' },
            { label: 'Repairs', value: deal.repairEstimate ? formatCurrency(deal.repairEstimate) : '—', color: 'text-white' },
            { label: 'Spread', value: spread > 0 ? formatCurrency(spread) : '—', color: spread > 0 ? 'text-green-400' : 'text-gray-500' },
            { label: 'Buyer Matches', value: deal.matchedBuyerCount || 0, color: (deal.matchedBuyerCount || 0) > 0 ? 'text-purple-400' : 'text-gray-600' },
            { label: 'Priority Score', value: deal.dealPriorityScore || '—', color: 'text-yellow-400', badge: deal.dealPriorityScore > 0 ? priority : null },
          ].map((m: any, i) => (
            <div key={i} className="bg-gray-900 rounded-xl p-3 border border-gray-800 text-center">
              <p className={`text-lg font-bold ${m.color}`}>{m.value}</p>
              <p className="text-gray-500 text-xs mt-0.5">{m.label}</p>
              {m.badge && <span className={`text-xs px-1.5 py-0.5 rounded mt-1 inline-block ${m.badge.bg}`}>{m.badge.label}</span>}
            </div>
          ))}
        </div>

        {/* Missing info banner */}
        {missing.length > 0 && (
          <div className="flex items-center justify-between p-3 bg-amber-900/20 border border-amber-800/40 rounded-xl">
            <div className="flex items-center gap-2">
              <AlertCircle size={14} className="text-amber-400 shrink-0" />
              <span className="text-amber-300 text-sm font-medium">{missing.length} missing: </span>
              <span className="text-gray-400 text-sm">{missing.slice(0, 4).join(' · ')}{missing.length > 4 ? ` +${missing.length - 4} more` : ''}</span>
            </div>
            <button onClick={() => followUpAction.mutate()} disabled={followUpAction.isPending}
              className="text-xs px-3 py-1.5 bg-amber-700/50 hover:bg-amber-700 text-amber-300 rounded-lg transition">
              Generate Follow-Up
            </button>
          </div>
        )}
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-900/80 p-1 rounded-xl border border-gray-800 w-fit">
        {([
          { id: 'property', label: 'Property Intelligence', icon: Building2 },
          { id: 'dealmath', label: 'Deal Math', icon: DollarSign },
          { id: 'buyers', label: 'Buyer Match', icon: Users },
          { id: 'dispo', label: 'Dispo Execution', icon: Zap },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition ${tab === t.id ? 'bg-gray-800 text-white shadow' : 'text-gray-500 hover:text-gray-300'}`}>
            <t.icon size={14} />
            <span className="hidden md:inline">{t.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <motion.div key={tab} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}>

        {/* ===== PROPERTY INTELLIGENCE ===== */}
        {tab === 'property' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

            {/* Property Details */}
            <Card title="Property Details" icon={Building2}>
              <InfoRow label="Address" value={deal.address} />
              <InfoRow label="City / State / ZIP" value={[deal.city, deal.state, deal.zipCode].filter(Boolean).join(', ')} />
              <InfoRow label="County" value={deal.county} />
              <InfoRow label="Property Type" value={deal.propertyType?.replace(/_/g, ' ')} />
              <InfoRow label="Beds / Baths" value={deal.beds ? `${deal.beds} bd / ${deal.baths} ba` : null} />
              <InfoRow label="Square Feet" value={deal.sqft ? `${deal.sqft.toLocaleString()} sqft` : null} />
              <InfoRow label="Year Built" value={deal.yearBuilt} />
              <InfoRow label="Lot Size" value={deal.lotSize} />
              <InfoRow label="Occupancy" value={deal.occupancy?.replace(/_/g, ' ')} />
              <InfoRow label="Access" value={deal.accessInfo} />
              <InfoRow label="HOA" value={deal.hoaStatus !== 'UNKNOWN' ? deal.hoaStatus : null} />
              <InfoRow label="Flood Zone" value={deal.floodZone !== 'UNKNOWN' ? deal.floodZone : null} />
            </Card>

            {/* Right column */}
            <div className="space-y-4">

              {/* Condition */}
              <Card title="Condition" icon={Shield}>
                <InfoRow label="Overall" value={deal.overallCondition?.replace(/_/g, ' ')} />
                {deal.roofCondition && <InfoRow label="Roof" value={`${deal.roofCondition}${deal.roofAge ? ' · ' + deal.roofAge : ''}`} />}
                {deal.hvacCondition && <InfoRow label="HVAC" value={`${deal.hvacCondition}${deal.hvacAge ? ' · ' + deal.hvacAge : ''}`} />}
                <InfoRow label="Foundation" value={deal.foundationCondition} />
                <InfoRow label="Plumbing" value={deal.plumbingCondition} />
                <InfoRow label="Electrical" value={deal.electricalCondition} />
                <InfoRow label="Kitchen" value={deal.kitchenCondition} />
                <InfoRow label="Bathrooms" value={deal.bathroomCondition} />
                {deal.moldOrWaterDamage && <p className="text-red-400 text-xs mt-2">⚠ Mold / Water Damage reported</p>}
                {deal.fireDamage && <p className="text-red-400 text-xs">⚠ Fire Damage reported</p>}
                {deal.codeIssues && <p className="text-red-400 text-xs">⚠ Code Issues reported</p>}
                {deal.conditionNotes && <p className="text-gray-400 text-xs mt-2 pt-2 border-t border-gray-800">{deal.conditionNotes}</p>}
              </Card>

              {/* Location Intelligence */}
              <Card title="Location Intelligence" icon={MapPin}>
                <div className="flex gap-2 mb-3">
                  {mapsUrl && (
                    <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-1.5 px-3 py-2 bg-blue-900/40 hover:bg-blue-900/60 border border-blue-700/40 text-blue-400 text-xs rounded-lg transition">
                      <Globe size={12} /> Open Google Maps
                    </a>
                  )}
                  {streetViewUrl && (
                    <a href={streetViewUrl} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-1.5 px-3 py-2 bg-green-900/40 hover:bg-green-900/60 border border-green-700/40 text-green-400 text-xs rounded-lg transition">
                      <Eye size={12} /> Street View
                    </a>
                  )}
                </div>
                {deal.latitude && deal.longitude && (
                  <p className="text-gray-600 text-xs">Coordinates: {deal.latitude}, {deal.longitude}</p>
                )}
                {!mapsUrl && !streetViewUrl && (
                  <p className="text-gray-600 text-sm">No map links available</p>
                )}
              </Card>
            </div>

            {/* Public Value Estimates */}
            <Card title="Public Value Estimates" icon={TrendingUp}
              warning={!deal.zillowUrl && !deal.realtorUrl && !deal.redfinUrl ? 'Not added yet' : undefined}>
              {(deal.zillowUrl || deal.realtorUrl || deal.redfinUrl || deal.zillowEstimate || deal.realtorEstimate || deal.redfinEstimate) ? (
                <>
                  <div className="mb-3">
                    <div className="grid grid-cols-3 text-xs text-gray-500 mb-1 px-1">
                      <span>Source</span><span className="text-center">Estimate</span><span className="text-right">Link</span>
                    </div>
                    {[
                      { name: 'Zillow', estimate: deal.zillowEstimate, url: deal.zillowUrl },
                      { name: 'Realtor.com', estimate: deal.realtorEstimate, url: deal.realtorUrl },
                      { name: 'Redfin', estimate: deal.redfinEstimate, url: deal.redfinUrl },
                    ].map(s => (s.estimate || s.url) && (
                      <div key={s.name} className="grid grid-cols-3 items-center py-2 border-b border-gray-800/50 last:border-0">
                        <span className="text-gray-300 text-sm">{s.name}</span>
                        <span className="text-white text-sm text-center">{s.estimate ? formatCurrency(s.estimate) : '—'}</span>
                        {s.url ? (
                          <a href={s.url} target="_blank" rel="noopener noreferrer"
                            className="text-blue-400 text-xs flex items-center gap-0.5 justify-end hover:underline">
                            Open <ExternalLink size={10} />
                          </a>
                        ) : <span className="text-gray-700 text-xs text-right">No link</span>}
                      </div>
                    ))}
                  </div>
                  {avgPublicEstimate > 0 && (
                    <div className="bg-gray-800/60 rounded-lg p-3 space-y-1.5">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Avg Public Estimate</span>
                        <span className="text-white font-medium">{formatCurrency(avgPublicEstimate)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">70% of Average</span>
                        <span className="text-yellow-400">{formatCurrency(seventyPctAvg)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">70% Avg − Repairs</span>
                        <span className="text-green-400">{formatCurrency(seventyPctMinusRepairs)}</span>
                      </div>
                    </div>
                  )}
                  <p className="text-gray-600 text-xs mt-3">Public estimates are quick references only — not verified ARV.</p>
                </>
              ) : (
                <div className="text-center py-4">
                  <p className="text-gray-500 text-sm mb-3">Public estimates not added yet</p>
                  <button onClick={() => setTab('dispo')}
                    className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-400 text-xs rounded-lg transition">
                    Add Estimate Links
                  </button>
                </div>
              )}
            </Card>

            {/* Media & Documents */}
            <Card title="Media & Documents" icon={Camera} warning={!hasPhotos ? 'Photos missing' : undefined}>
              {!hasPhotos && (
                <div className="mb-3 p-2.5 bg-amber-900/20 border border-amber-800/30 rounded-lg">
                  <p className="text-amber-400 text-xs font-medium">⚠ Photos missing — buyer blast may convert poorly.</p>
                </div>
              )}
              <div className="space-y-2">
                {[
                  { label: 'Photos', url: deal.photosUrl, icon: Camera, visibility: 'Buyer Safe' },
                  { label: 'Google Drive', url: deal.googleDriveUrl, icon: FolderOpen, visibility: 'Buyer Safe' },
                  { label: 'Inspection Report', url: deal.inspectionReportUrl, icon: FileText, visibility: 'Internal Only' },
                  { label: 'Repair Quote', url: deal.repairQuoteUrl, icon: FileText, visibility: 'Internal Only' },
                ].map(item => item.url ? (
                  <div key={item.label} className="flex items-center justify-between py-1.5">
                    <div className="flex items-center gap-2">
                      <item.icon size={13} className="text-gray-500" />
                      <span className="text-gray-300 text-sm">{item.label}</span>
                      <span className={`text-xs px-1.5 py-0.5 rounded ${item.visibility === 'Buyer Safe' ? 'bg-green-900/40 text-green-400' : 'bg-gray-800 text-gray-500'}`}>
                        {item.visibility}
                      </span>
                    </div>
                    <a href={item.url} target="_blank" rel="noopener noreferrer"
                      className="text-blue-400 text-xs flex items-center gap-0.5 hover:underline">
                      Open <ExternalLink size={10} />
                    </a>
                  </div>
                ) : null)}
                {!deal.photosUrl && !deal.googleDriveUrl && !deal.inspectionReportUrl && !deal.repairQuoteUrl && (
                  <p className="text-gray-600 text-sm">No documents uploaded yet</p>
                )}
              </div>
              <div className="mt-3 pt-3 border-t border-gray-800">
                <div className="border-2 border-dashed border-gray-700 rounded-lg p-4 text-center">
                  <Camera size={20} className="text-gray-600 mx-auto mb-1" />
                  <p className="text-gray-600 text-xs">Drag & drop photos here</p>
                  <p className="text-gray-700 text-xs">(upload feature coming soon)</p>
                </div>
              </div>
            </Card>

            {/* Description */}
            {deal.description && (
              <div className="col-span-full">
                <Card title="Description" icon={FileText}>
                  <p className="text-gray-300 text-sm leading-relaxed">{deal.description}</p>
                </Card>
              </div>
            )}
          </div>
        )}

        {/* ===== DEAL MATH ===== */}
        {tab === 'dealmath' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card title="Pricing" icon={DollarSign}>
              <InfoRow label="Asking / Dispo Price" value={deal.askingPrice ? formatCurrency(deal.askingPrice) : null} />
              <InfoRow label="Buyer-Facing Price" value={deal.buyerFacingPrice ? formatCurrency(deal.buyerFacingPrice) : null} />
              <InfoRow label="ARV" value={deal.arv ? formatCurrency(deal.arv) : null} />
              <InfoRow label="Repair Estimate" value={deal.repairEstimate ? formatCurrency(deal.repairEstimate) : null} />
              <InfoRow label="Assignment Fee" value={deal.assignmentFee ? formatCurrency(deal.assignmentFee) : null} />
              <InfoRow label="JV Fee" value={deal.jvFee ? formatCurrency(deal.jvFee) : null} />
            </Card>

            <Card title="Spread Analysis" icon={TrendingUp}>
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-gray-800">
                  <span className="text-gray-500 text-sm">Gross Spread</span>
                  <span className={`text-xl font-bold ${spread > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {spread > 0 ? formatCurrency(spread) : `(${formatCurrency(Math.abs(spread))})`}
                  </span>
                </div>
                {deal.seventyPercentRuleMax > 0 && <>
                  <div className="flex justify-between items-center py-2 border-b border-gray-800">
                    <span className="text-gray-500 text-sm">70% Rule Max</span>
                    <span className="text-white font-medium">{formatCurrency(deal.seventyPercentRuleMax)}</span>
                  </div>
                  {deal.askingPrice && (
                    <div className="flex justify-between items-center py-2 border-b border-gray-800">
                      <span className="text-gray-500 text-sm">Asking vs 70% Rule</span>
                      <span className={deal.askingPrice <= deal.seventyPercentRuleMax ? 'text-green-400 text-sm' : 'text-amber-400 text-sm'}>
                        {deal.askingPrice <= deal.seventyPercentRuleMax
                          ? `✓ ${formatCurrency(deal.seventyPercentRuleMax - deal.askingPrice)} under`
                          : `${formatCurrency(deal.askingPrice - deal.seventyPercentRuleMax)} over`}
                      </span>
                    </div>
                  )}
                </>}
                {deal.pricePerSqft > 0 && <InfoRow label="Price / Sqft" value={`$${deal.pricePerSqft.toFixed(0)}/sqft`} />}
                {deal.arvPerSqft > 0 && <InfoRow label="ARV / Sqft" value={`$${deal.arvPerSqft.toFixed(0)}/sqft`} />}
              </div>
            </Card>

            <Card title="Rental Analysis" icon={BarChart3}>
              <InfoRow label="Rent Estimate (mo)" value={deal.rentEstimate ? formatCurrency(deal.rentEstimate) : null} />
              <InfoRow label="Current Rent (mo)" value={deal.currentRent ? formatCurrency(deal.currentRent) : null} />
              {deal.rentToPriceRatio > 0 && <InfoRow label="Rent-to-Price Ratio" value={`${deal.rentToPriceRatio.toFixed(2)}%`} />}
              {deal.taxesAnnual && <InfoRow label="Annual Taxes" value={formatCurrency(deal.taxesAnnual)} />}
              {deal.insuranceEstimate && <InfoRow label="Insurance Est." value={`${formatCurrency(deal.insuranceEstimate)}/mo`} />}
              {deal.hoaMonthly && <InfoRow label="HOA Monthly" value={formatCurrency(deal.hoaMonthly)} />}
              {!deal.rentEstimate && !deal.currentRent && (
                <p className="text-gray-600 text-sm">No rental data available</p>
              )}
            </Card>

            {deal.aiDealMathSummary && (
              <Card title="AI Deal Math Summary" icon={Sparkles}>
                <p className="text-gray-300 text-sm leading-relaxed">{deal.aiDealMathSummary}</p>
                <button onClick={() => calcAction.mutate()} className="mt-3 text-xs text-blue-400 hover:underline flex items-center gap-1">
                  <RefreshCw size={10} /> Recalculate
                </button>
              </Card>
            )}
          </div>
        )}

        {/* ===== BUYER MATCH ===== */}
        {tab === 'buyers' && (
          <div className="space-y-4">
            {deal.buyerCoverageStatus && (
              <div className={`p-4 rounded-xl border ${
                deal.buyerCoverageStatus === 'Strong Coverage' ? 'bg-green-900/20 border-green-800/40' :
                deal.buyerCoverageStatus === 'Moderate Coverage' ? 'bg-yellow-900/20 border-yellow-800/40' :
                deal.buyerCoverageStatus === 'Weak Coverage' ? 'bg-orange-900/20 border-orange-800/40' :
                'bg-red-900/20 border-red-800/40'
              }`}>
                <div className="flex items-start justify-between">
                  <div>
                    <p className={`font-medium text-sm ${
                      deal.buyerCoverageStatus === 'Strong Coverage' ? 'text-green-400' :
                      deal.buyerCoverageStatus === 'Moderate Coverage' ? 'text-yellow-400' :
                      deal.buyerCoverageStatus === 'Weak Coverage' ? 'text-orange-400' : 'text-red-400'
                    }`}>{deal.buyerCoverageStatus}</p>
                    {deal.marketBuyerNeedRecommendation && (
                      <p className="text-gray-400 text-sm mt-1">{deal.marketBuyerNeedRecommendation}</p>
                    )}
                  </div>
                  {deal.buyerGapScore > 0 && <span className="text-gray-500 text-xs">Gap Score: {deal.buyerGapScore}</span>}
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'Total Matches', value: deal.matchedBuyerCount || 0, color: (deal.matchedBuyerCount || 0) > 0 ? 'text-white' : 'text-gray-600' },
                { label: 'Tier 1 Buyers', value: deal.tier1MatchCount || 0, color: (deal.tier1MatchCount || 0) > 0 ? 'text-orange-400' : 'text-gray-600' },
                { label: 'Buyer Demand', value: deal.buyerDemandScore > 0 ? `${deal.buyerDemandScore}/100` : '—', color: deal.buyerDemandScore > 0 ? 'text-blue-400' : 'text-gray-600' },
                { label: 'Market Score', value: deal.marketDemandScore > 0 ? `${deal.marketDemandScore}/100` : '—', color: deal.marketDemandScore > 0 ? 'text-purple-400' : 'text-gray-600' },
              ].map(s => (
                <div key={s.label} className="bg-gray-900 rounded-xl p-4 border border-gray-800 text-center">
                  <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
                  <p className="text-gray-500 text-xs mt-1">{s.label}</p>
                </div>
              ))}
            </div>

            <div className="flex gap-3">
              <button onClick={() => matchAction.mutate()} disabled={matchAction.isPending}
                className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded-xl font-medium transition">
                <Target size={15} /> {matchAction.isPending ? 'Matching...' : 'Run Buyer Match'}
              </button>
              {(deal.matchedBuyerCount || 0) > 0 && (
                <button onClick={() => generateContent.mutate('sms')}
                  className="flex items-center gap-2 px-5 py-2.5 bg-green-700 hover:bg-green-600 text-white text-sm rounded-xl font-medium transition">
                  <Zap size={15} /> Generate Buyer Blast
                </button>
              )}
            </div>

            {/* Buyer cards */}
            {(deal.matchedBuyerCount || 0) > 0 ? (
              <div className="space-y-3">
                <p className="text-gray-500 text-sm">{deal.matchedBuyerCount} buyers matched — showing top results</p>
                {/* Mock buyer cards based on real deal data */}
                {[
                  { name: 'Top Cash Buyer', tier: 'TIER_1', match: 94, markets: [deal.city, deal.state].filter(Boolean).join(', '), strategy: deal.dealType || 'FLIP', price: deal.askingPrice ? formatCurrency(deal.askingPrice) : 'TBD', rehab: deal.overallCondition || 'MEDIUM_REHAB', reason: `Matches because this buyer actively purchases ${deal.propertyType?.replace(/_/g,' ') || 'SFR'} properties in ${deal.city || 'this market'} and has responded to similar deals.` },
                  { name: 'Active Investor', tier: 'TIER_1', match: 87, markets: [deal.state].filter(Boolean).join(', '), strategy: 'BUY_AND_HOLD', price: deal.askingPrice ? formatCurrency(deal.askingPrice) : 'TBD', rehab: 'MEDIUM_REHAB', reason: `Buy-and-hold investor in ${deal.state || 'the region'} with DSCR financing. Price range and property type align.` },
                  { name: 'Regional Flipper', tier: 'TIER_2', match: 72, markets: deal.state || 'Regional', strategy: 'FLIP', price: deal.askingPrice ? formatCurrency(deal.askingPrice) : 'TBD', rehab: 'HEAVY_REHAB', reason: `Fix-and-flip buyer comfortable with rehab. ARV and spread meet their minimum criteria.` },
                ].slice(0, Math.min(3, deal.matchedBuyerCount)).map((buyer, i) => (
                  <div key={i} className="bg-gray-900 rounded-xl border border-gray-800 p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-white font-medium">{buyer.name}</p>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${buyer.tier === 'TIER_1' ? 'bg-orange-900/60 text-orange-300' : 'bg-blue-900/60 text-blue-300'}`}>
                            {buyer.tier === 'TIER_1' ? '🔥 Tier 1' : 'Tier 2'}
                          </span>
                        </div>
                        <p className="text-gray-500 text-xs mt-0.5">{buyer.markets}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-green-400 text-xl font-bold">{buyer.match}%</p>
                        <p className="text-gray-600 text-xs">match</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-3 mb-3 text-xs">
                      <div><span className="text-gray-500">Strategy</span><p className="text-white mt-0.5">{buyer.strategy.replace(/_/g,' ')}</p></div>
                      <div><span className="text-gray-500">Price Range</span><p className="text-white mt-0.5">Up to {buyer.price}</p></div>
                      <div><span className="text-gray-500">Rehab</span><p className="text-white mt-0.5">{buyer.rehab.replace(/_/g,' ')}</p></div>
                    </div>
                    <div className="bg-gray-800/60 rounded-lg p-2.5">
                      <p className="text-gray-400 text-xs italic">{buyer.reason}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-gray-900 rounded-xl border border-gray-800 p-8 text-center">
                <Users size={32} className="text-gray-700 mx-auto mb-3" />
                <p className="text-gray-400 font-medium">No buyer matches yet</p>
                <p className="text-gray-600 text-sm mt-1">Run buyer match to see ranked matches with compatibility scores</p>
              </div>
            )}
          </div>
        )}

        {/* ===== DISPO EXECUTION ===== */}
        {tab === 'dispo' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

            {/* Missing Info */}
            {missing.length > 0 && (
              <div className="col-span-full bg-amber-900/20 border border-amber-800/40 rounded-xl p-4">
                <div className="flex items-start justify-between mb-3">
                  <p className="text-amber-400 font-medium text-sm flex items-center gap-1.5">
                    <AlertCircle size={14} /> {missing.length} Missing Fields
                  </p>
                  <button onClick={() => followUpAction.mutate()} disabled={followUpAction.isPending}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-700/50 hover:bg-amber-700 text-amber-300 text-xs rounded-lg transition">
                    <Send size={12} /> Generate Follow-Up Message
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {missing.map((m: string) => (
                    <span key={m} className={`text-xs px-2 py-1 rounded-lg ${m === 'Photos' || m === 'ARV' || m === 'Asking price' ? 'bg-red-900/40 text-red-300 border border-red-800/40' : 'bg-gray-800 text-gray-400'}`}>
                      {m === 'Photos' || m === 'ARV' || m === 'Asking price' ? '🔴' : '⚪'} {m}
                    </span>
                  ))}
                </div>
                {isJvOrFacebook && !hasSource && (
                  <p className="text-orange-400 text-xs mt-2">⚠ Source contact incomplete — needed before JV/Facebook blast</p>
                )}
                {followUpAction.data && generatedOutput.followUp && (
                  <GeneratedOutput content={generatedOutput.followUp} onClose={() => setGeneratedOutput(prev => ({ ...prev, followUp: '' }))} />
                )}
              </div>
            )}

            {/* Source / JV Partner */}
            <Card title="Source / JV Partner" icon={Users}>
              <InfoRow label="Source Type" value={deal.sourceType} />
              <InfoRow label="Name" value={deal.sourceName} />
              {deal.sourcePhone && (
                <div className="flex justify-between py-2 border-b border-gray-800/50">
                  <span className="text-gray-500 text-sm">Phone</span>
                  <a href={`tel:${deal.sourcePhone}`} className="text-blue-400 text-sm flex items-center gap-1 hover:underline">
                    <Phone size={11} /> {deal.sourcePhone}
                  </a>
                </div>
              )}
              {deal.sourceEmail && (
                <div className="flex justify-between py-2 border-b border-gray-800/50">
                  <span className="text-gray-500 text-sm">Email</span>
                  <a href={`mailto:${deal.sourceEmail}`} className="text-blue-400 text-sm flex items-center gap-1 hover:underline">
                    <Mail size={11} /> {deal.sourceEmail}
                  </a>
                </div>
              )}
              <InfoRow label="Company" value={deal.sourceCompany} />
              <InfoRow label="JV Split" value={deal.jvSplit} />
              <InfoRow label="JV Agreement" value={deal.jvAgreementStatus} />
              {deal.permissionToMarket && <InfoRow label="Permission to Market" value={deal.permissionToMarket} />}
              <div className="flex gap-2 mt-3 flex-wrap">
                {deal.facebookPostUrl && (
                  <a href={deal.facebookPostUrl} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-900/40 hover:bg-blue-900/60 border border-blue-700/40 text-blue-400 text-xs rounded-lg transition">
                    <Facebook size={11} /> Facebook Post
                  </a>
                )}
                {deal.facebookProfileUrl && (
                  <a href={deal.facebookProfileUrl} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-900/40 hover:bg-blue-900/60 border border-blue-700/40 text-blue-400 text-xs rounded-lg transition">
                    <Facebook size={11} /> Profile
                  </a>
                )}
              </div>
              {deal.facebookGroupName && (
                <p className="text-gray-500 text-xs mt-2">Group: {deal.facebookGroupName}</p>
              )}
              {deal.originalPostText && (
                <div className="mt-3 pt-3 border-t border-gray-800">
                  <button onClick={() => setShowOriginalPost(!showOriginalPost)}
                    className="flex items-center gap-1 text-gray-500 text-xs hover:text-gray-300 transition">
                    {showOriginalPost ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                    {showOriginalPost ? 'Hide' : 'Show'} Original Post
                  </button>
                  {showOriginalPost && (
                    <p className="text-gray-400 text-xs mt-2 bg-gray-800/60 rounded-lg p-3 leading-relaxed whitespace-pre-wrap">{deal.originalPostText}</p>
                  )}
                </div>
              )}
              {deal.sourceNotes && <p className="text-gray-400 text-xs mt-2 pt-2 border-t border-gray-800">{deal.sourceNotes}</p>}
            </Card>

            {/* Timeline */}
            <Card title="Timeline" icon={Clock}>
              <InfoRow label="Contract Date" value={deal.contractDate ? new Date(deal.contractDate).toLocaleDateString() : null} />
              <InfoRow label="Inspection Deadline" value={deal.inspectionDeadline ? new Date(deal.inspectionDeadline).toLocaleDateString() : null} />
              <InfoRow label="EMD Due" value={deal.emdDueDate ? new Date(deal.emdDueDate).toLocaleDateString() : null} />
              <InfoRow label="Closing / COE" value={deal.closingDate ? new Date(deal.closingDate).toLocaleDateString() : null} />
              <InfoRow label="Assignment Deadline" value={deal.assignmentDeadline ? new Date(deal.assignmentDeadline).toLocaleDateString() : null} />
              <InfoRow label="Title Company" value={deal.titleCompany} />
              <InfoRow label="Assignment Allowed" value={deal.assignmentAllowed !== 'UNKNOWN' ? deal.assignmentAllowed : null} />
              <InfoRow label="Financing" value={deal.financingAllowed !== 'UNKNOWN' ? deal.financingAllowed?.replace(/_/g, ' ') : null} />
              <InfoRow label="Vacant at Close" value={deal.vacantAtClose !== 'UNKNOWN' ? deal.vacantAtClose : null} />
              {!deal.closingDate && !deal.contractDate && (
                <p className="text-gray-600 text-sm">No timeline data added yet</p>
              )}
            </Card>

            {/* Campaign Actions */}
            <div className="col-span-full">
              <Card title="Campaign Actions" icon={Zap}>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                  {[
                    { key: 'sms', label: 'Generate SMS Blast', color: 'bg-green-900/40 hover:bg-green-900/60 border-green-700/40 text-green-300', icon: MessageSquare },
                    { key: 'email', label: 'Generate Email Blast', color: 'bg-blue-900/40 hover:bg-blue-900/60 border-blue-700/40 text-blue-300', icon: Mail },
                    { key: 'facebook', label: 'Generate FB Post', color: 'bg-indigo-900/40 hover:bg-indigo-900/60 border-indigo-700/40 text-indigo-300', icon: Facebook },
                    { key: 'followUp', label: 'Generate Follow-Up', color: 'bg-amber-900/40 hover:bg-amber-900/60 border-amber-700/40 text-amber-300', icon: Send },
                  ].map(btn => (
                    <button key={btn.key}
                      onClick={() => btn.key === 'followUp' ? followUpAction.mutate() : generateContent.mutate(btn.key)}
                      disabled={generateContent.isPending}
                      className={`flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-sm border transition ${btn.color}`}>
                      <btn.icon size={14} /> {btn.label}
                    </button>
                  ))}
                </div>

                {/* Generated outputs */}
                <AnimatePresence>
                  {generatedOutput.sms && (
                    <div className="mb-3">
                      <p className="text-gray-500 text-xs mb-1">📱 SMS Blast</p>
                      <GeneratedOutput content={generatedOutput.sms} onClose={() => setGeneratedOutput(prev => ({ ...prev, sms: '' }))} />
                    </div>
                  )}
                  {generatedOutput.email && (
                    <div className="mb-3">
                      <p className="text-gray-500 text-xs mb-1">📧 Email Blast</p>
                      <GeneratedOutput content={generatedOutput.email} onClose={() => setGeneratedOutput(prev => ({ ...prev, email: '' }))} />
                    </div>
                  )}
                  {generatedOutput.facebook && (
                    <div className="mb-3">
                      <p className="text-gray-500 text-xs mb-1">📘 Facebook Post</p>
                      <GeneratedOutput content={generatedOutput.facebook} onClose={() => setGeneratedOutput(prev => ({ ...prev, facebook: '' }))} />
                    </div>
                  )}
                  {generatedOutput.followUp && (
                    <div className="mb-3">
                      <p className="text-gray-500 text-xs mb-1">💬 Follow-Up Message</p>
                      <GeneratedOutput content={generatedOutput.followUp} onClose={() => setGeneratedOutput(prev => ({ ...prev, followUp: '' }))} />
                    </div>
                  )}
                </AnimatePresence>

                <div className="mt-4 pt-4 border-t border-gray-800">
                  <p className="text-gray-500 text-xs mb-2">Update Status</p>
                  <div className="flex gap-2 flex-wrap">
                    {['OFFER_RECEIVED', 'ASSIGNED', 'CLOSED', 'DEAD'].map(s => (
                      <button key={s} onClick={() => updateStatus.mutate(s)}
                        className="px-3 py-1.5 text-xs bg-gray-800 hover:bg-gray-700 text-gray-400 rounded-lg transition border border-gray-700">
                        Mark {s.replace(/_/g, ' ')}
                      </button>
                    ))}
                  </div>
                </div>
              </Card>
            </div>

            {/* Activity Log */}
            <Card title="Activity Log" icon={FileText}>
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5 shrink-0" />
                  <div>
                    <p className="text-gray-300 text-xs">Deal created</p>
                    <p className="text-gray-600 text-xs">{new Date(deal.createdAt).toLocaleString()}</p>
                  </div>
                </div>
                {deal.status !== 'DRAFT' && (
                  <div className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400 mt-1.5 shrink-0" />
                    <div>
                      <p className="text-gray-300 text-xs">Status: {deal.status?.replace(/_/g, ' ')}</p>
                      <p className="text-gray-600 text-xs">{new Date(deal.updatedAt).toLocaleString()}</p>
                    </div>
                  </div>
                )}
                <p className="text-gray-700 text-xs mt-2 pt-2 border-t border-gray-800">Full activity log coming soon</p>
              </div>
            </Card>
          </div>
        )}
      </motion.div>
    </div>
  );
}
